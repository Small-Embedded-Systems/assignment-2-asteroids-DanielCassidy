/* Asteroids view
*/

/* C libraries */
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>

/* hardware platform libraries */
#include <display.h>
#include <mbed.h>

#include "asteroids.h"
#include "model.h"
#include "utils.h"

Display *graphics = Display::theDisplay();

const colour_t background = rgb(0,25,35);
const colour_t sidebar = rgb(25,50,60);


const coordinate_t shape[] = {
    {10,0}, {-5,5}, {-5,-5}
};

/* double buffering functions */
void init_DBuffer(void)
{   /* initialise the LCD driver to use second frame in buffer */
    uint16_t *bufferbase = graphics->getFb();
    uint16_t *nextbuffer = bufferbase+ (480*272);
    LPC_LCD->UPBASE = (uint32_t)nextbuffer;
}

void swap_DBuffer(void)
{   /* swaps frames used by the LCD driver and the graphics object */
    uint16_t *buffer = graphics->getFb();
    graphics->setFb( (uint16_t*) LPC_LCD->UPBASE);
    LPC_LCD->UPBASE = (uint32_t)buffer;
}

/* Draw sidebar, containing elapsed time, score, 
	 lives, and previous score */
void draw_sidebar(int e_t, int sc, int li) {
	graphics->fillRect(0, 0, 80, 275, sidebar);
	  graphics->setTextColor(WHITE, sidebar);
		graphics->setCursor(20, 10);
			graphics->printf("CM0506");
		graphics->setCursor(2, 20);
			graphics->printf("Assignment 2:");
		graphics->setCursor(10, 30);
			graphics->printf("Asteroids");
		graphics->setCursor(27, 50);
			graphics->printf("Time");
		graphics->setCursor(18, 60);
	    graphics->printf("elapsed:");
		graphics->setCursor(35, 70);
	    graphics->printf("%d", e_t);
		graphics->setCursor(25, 90);
	    graphics->printf("Score:");
		graphics->setCursor(35, 100);
	    graphics->printf("%d", sc);
		graphics->setCursor(25, 120);
		  graphics->printf("Lives:");
		graphics->setCursor(35, 130);
	    graphics->printf("%d", li);
		graphics->setCursor(17, 190);
		  graphics->printf("Previous");
		graphics->setCursor(25, 200);
			graphics->printf("score:");
		graphics->setCursor(35, 210);
	    graphics->printf("%d", prevscore);
			
			if (paused) {
				graphics->setCursor(180, 90);
					graphics->setTextColor(WHITE, background);
					graphics->printf("Press joystick CENTRE to begin");
			}
}

/* Draw ship based on heading,
	 also changes the colour to red if the player has
	 taken damage */
void draw_ship(ship player) {
	if (player.heading == 0) { // north
		graphics->fillTriangle(player.p.x, player.p.y-4,
		player.p.x-2, player.p.y+2,
		player.p.x+2, player.p.y+2,
		WHITE);
				if (player.lostlife == 1) {
			graphics->fillTriangle(player.p.x, player.p.y-4,
			player.p.x-2, player.p.y+2,
			player.p.x+2, player.p.y+2,
			RED);
			}
	}
	
	if (player.heading == 1) { // north-east
		graphics->fillTriangle(player.p.x-3, player.p.y-3,
		player.p.x, player.p.y+3,
		player.p.x+3, player.p.y,
		WHITE);
			if (player.lostlife == 1) {
				graphics->fillTriangle(player.p.x-3, player.p.y-3,
				player.p.x, player.p.y+3,
				player.p.x+3, player.p.y,
				RED);
			}
	}

	if (player.heading == 2) { // east
		graphics->fillTriangle(player.p.x-4, player.p.y,
		player.p.x+2, player.p.y+2,
		player.p.x+2, player.p.y-2,
		WHITE);			  
			if (player.lostlife == 1) {
				graphics->fillTriangle(player.p.x-4, player.p.y,
				player.p.x+2, player.p.y+2,
				player.p.x+2, player.p.y-2,
				RED);
			}
	}

	if (player.heading == 3) { // south-east
		graphics->fillTriangle(player.p.x-3, player.p.y+3,
		player.p.x+3, player.p.y,
		player.p.x, player.p.y-3,
		WHITE);
			if (player.lostlife == 1) {
				graphics->fillTriangle(player.p.x-3, player.p.y+3,
				player.p.x+3, player.p.y,
				player.p.x, player.p.y-3,
				RED);
			}
	}

	if (player.heading == 4) { // south
		graphics->fillTriangle(player.p.x, player.p.y+4,
		player.p.x+2, player.p.y-2,
		player.p.x-2, player.p.y-2,
		WHITE);
			if (player.lostlife == 1) {
				graphics->fillTriangle(player.p.x, player.p.y+4,
				player.p.x+2, player.p.y-2,
				player.p.x-2, player.p.y-2,
				RED);
			}
	}

	if (player.heading == 5) { // south-west
		graphics->fillTriangle(player.p.x+3, player.p.y+3,
		player.p.x, player.p.y-3,
		player.p.x-3, player.p.y,
		WHITE);
			if (player.lostlife == 1) {
				graphics->fillTriangle(player.p.x+3, player.p.y+3,
				player.p.x, player.p.y-3,
				player.p.x-3, player.p.y,
				RED);
			}
	}

	if (player.heading == 6) { // west
		graphics->fillTriangle(player.p.x+4, player.p.y,
		player.p.x-2, player.p.y-2,
		player.p.x-2, player.p.y+2,
		WHITE);
			if (player.lostlife == 1) {
				graphics->fillTriangle(player.p.x+4, player.p.y,
				player.p.x-2, player.p.y-2,
				player.p.x-2, player.p.y+2,
				RED);
			}
	}

	if (player.heading == 7) { // north-west
		graphics->fillTriangle(player.p.x+3, player.p.y-3,
		player.p.x-3, player.p.y,
		player.p.x, player.p.y+3,
		WHITE);
			if (player.lostlife == 1) {
				graphics->fillTriangle(player.p.x+3, player.p.y-3,
				player.p.x-3, player.p.y,
				player.p.x, player.p.y+3,
				RED);
			}
	}
}

void drawmissiles(struct missile *lst)
{
    // while there are missiles to draw
    while(lst) {
        graphics->fillCircle(lst->p.x,lst->p.y, 1, RED);
        lst = lst->next; // iterate along the list
    }
}

void drawasteroids(struct asteroid *lst)
{
    // while there are asteroids to draw
    while(lst) {
      graphics->fillCircle(lst->p.x,lst->p.y, 20, WHITE);
			lst = lst->next; // iterate along the list
    }
}

void draw(void)
{
    graphics->fillScreen(background);
	
		draw_ship(player);
		drawmissiles(shots);
		drawasteroids(asteroids);
		draw_sidebar(elapsed_time, score, lives);
	
    swap_DBuffer();
}
